# Three prisoners' problem
set.seed(100)
samplesize<-1000000
governor<-sample(0:2,samplesize,replace=T)
wardensinfo<-function(a,j) {
	if (a[j]==0) {thisone<-sample(1:2,1,replace=T)}
	if (a[j]==1) {thisone<-2}
	if (a[j]==2) {thisone<-1}	
thisone # output
}
warden<- sapply(1:samplesize, function(j) wardensinfo(governor,j))
r<-data.frame(governor,warden)
# Warden told B, given governor choose A.
round(sum(r$warden==1 & r$governor==0)/sum(r$warden==1),4)
# Warden told C, given governor choose A.
round(sum(r$warden==2 & r$governor==0)/sum(r$warden==2),4)
# Warden told B, given governor choose C. 
round(sum(r$warden==1 & r$governor==2)/sum(r$warden==1),4)
# Warden told C, given governor choose B. 
round(sum(r$warden==2 & r$governor==1)/sum(r$warden==2),4)




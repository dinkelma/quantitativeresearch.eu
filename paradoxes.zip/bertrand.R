#Bertrand's paradox
set.seed(100) 
samplesize<-1000000
a<-sample(0:2,samplesize,replace=T)
# 3 boxes: 0- gold, gold; 1 - silver, silver; 2 - gold, silver
b<-sample(0:1,samplesize,replace=T) # 2 balls in each box
data<-data.frame(a,b) 
data2<-subset(data,(a==0) | (a==2 & b==0),select=a)
round(sum(a==0)/nrow(data2),4) # final probability


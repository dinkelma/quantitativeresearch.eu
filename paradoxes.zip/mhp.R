#Monty Hall problem
samplesize<-100000 # sample size
doors<-9 # doors count -1
door<-vector("numeric",length=doors*(doors-1)/2)
prize<-vector("numeric",length=doors*(doors-1)/2)
changedp<-vector("numeric",length=doors*(doors-1)/2)
nochangep<-vector("numeric",length=doors*(doors-1)/2)
ttp<-vector("numeric",length=doors*(doors-1)/2)
ottp<-vector("numeric",length=doors*(doors-1)/2)
flipp<-vector("numeric",length=doors*(doors-1)/2)
results <- data.frame(door, prize, changedp, ttp,flipp,
ottp,nochangep)
#tic-toc oppposite tic-toc function
ttott<-function(ttott1,win1,win2,trigger){
 if (ttott1==0) {if (win2==0) {thisone<-0
	} else {thisone<-1 }}
    if (ttott1==1) {if (win1==0) {thisone<-1
      } else {thisone<-0 }}
if (trigger=="ott") {if (thisone==0) {thisone<-1   
    } else {thisone<-0 }}    
thisone}
for (i in 2:doors) {
 for (j in 1:(i-1)) {
   set.seed(100) 
   initial<-replicate(samplesize,list(sample(0:i,1,replace=F)))
   priz<-replicate(samplesize,list(sample(0:i,j,replace=F)))
   # initial guess & prizes behind doors
   flip<-sample(0:1,samplesize, replace=T) # flip a coin
   tt<-sample(0,samplesize,replace=T) # tic toc
   ott<-sample(0,samplesize,replace=T) # opposite tic toc
   choices<-replicate(samplesize,list(c(0:i)))
   # WHICH GOAT WILL BE SHOWN
   goats<-mapply(setdiff,choices,priz) 
   goats2<- lapply(1:ncol(goats), function(p) goats[,p])
   # goats are opposite prizes
   notinitial<-mapply(setdiff,choices,initial) 
   notinitial2<-lapply(1:ncol(notinitial),
   function(p) notinitial[,p])
   # group of not initial decisions
   goats3<-mapply(intersect,goats2,notinitial2) 
   goats4<-lapply(goats3, function(p) c(p,p))
   goat<-lapply(goats4, function(p) sample(p,1))
   # to show just one goat from intersect not initial & goats
   remove(goats,goats2,choices,notinitial,goats3,goats4)
   chmind<-mapply(setdiff,notinitial2,goat)#to change mind
   #to exclude goat which was shown from not initial group
   if (is.null(ncol(chmind))==FALSE) {
    chmind2<- lapply(1:ncol(chmind), function(p) chmind[,p]) 
    } else {chmind2<-chmind } 
   chmind3<-lapply(chmind2, function(p) c(p,p))
   newmind<-lapply(chmind3, function(p) sample(p,1))
   # to choose 1 new decision from all the available
   remove(notinitial2, goat,chmind,chmind2,chmind3)
   win1<-mapply(intersect,newmind,priz)#win1 changed mind
   win2<-mapply(intersect,initial,priz)#win2 not changed mind
   win13<-as.numeric(lapply(win1,function(p) length(p)==0))
   win23<-as.numeric(lapply(win2, function(p) length(p)==0))
   # intersection - 1 no intersection,0 intersection
   for(l in 1:(samplesize-1)) { # TIC-TOC, OPPOSITE TIC TOC
    tt[l+1]<-ttott(tt[l],win13[l],win23[l],'tt')
    ott[l+1]<-ttott(ott[l],win13[l],win23[l],'ott')}
   #PROBABILITIES
   win1p<-sum(win13==0)/samplesize #win1p changed mind
   win2p<-sum(win23==0)/samplesize #win2p not changed mind
   remove(newmind,priz,initial,win1,win2)
   flipfr<-data.frame(win13,win23,flip,tt,ott)
   flip1<-nrow(flipfr[flipfr$flip==1 & flipfr$win13==0,])
   flip2<-nrow(flipfr[flipfr$flip==0 & flipfr$win23==0,])
   # flip1 - changed mind,flip2 - initial decision 
   tt1<-nrow(flipfr[flipfr$tt==1 & flipfr$win13==0,]) 
   tt2<-nrow(flipfr[flipfr$tt==0 & flipfr$win23==0,])
   ott1<-nrow(flipfr[flipfr$ott==1 & flipfr$win13==0,])
   ott2<-nrow(flipfr[flipfr$ott==0 & flipfr$win23==0,])
   flipp<-(flip1+flip2)/samplesize
   tictocp<-(tt1+tt2)/samplesize
   opptictocp<-(ott1+ott2)/samplesize
   results$door[i*(i-1)/2-i+1+j]<-i+1#RESULTS - WRITTING   
   results$prize[i*(i-1)/2-i+1+j]<-j
   results$changedp[i*(i-1)/2-i+1+j]<-round(win1p*100,3)
   results$ttp[i*(i-1)/2-i+1+j]<-round(tictocp*100,3)
   results$flipp[i*(i-1)/2-i+1+j]<-round(flipp*100,3)
   results$ottp[i*(i-1)/2-i+1+j]<-round(opptictocp*100,3)
   results$nochangep[i*(i-1)/2-i+1+j]<-round(win2p*100,3)
   remove(win13,win23,flipfr,flip,tt,ott) } }
nname<- paste(toString(samplesize),"r.txt",sep="")
write.table(results,nname,append=FALSE)


